-- 爬爬的 DST / Switch mod 实验：打开 mod 系统
-- 由 build_overlay.py 生成，覆盖 romfs/scripts/globalvariableoverrides.lua
MODS_ENABLED = true
DISABLE_MOD_WARNING = true

-- 引擎在 PC 上给的是 "../mods/"（见二进制里的 "[string \"../mods/" 字面量），
-- 主机上那个相对路径解析不到 romfs 内的目录，所以这里直接指到 romfs 根下的 mods/。
MODS_ROOT = "mods/"
