-- 最小验证 mod：出生时给一块金块
AddPlayerPostInit(function(inst)
    inst:DoTaskInTime(0, function()
        if inst.components.inventory ~= nil then
            inst.components.inventory:GiveItem(SpawnPrefab("goldnugget"))
        end
    end)
end)
